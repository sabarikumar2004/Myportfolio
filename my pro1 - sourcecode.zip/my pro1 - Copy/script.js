const sentences = [
  "I'm Sabari Kumar.",
];

let i = 0, j = 0;
let current = "";
let isDeleting = false;

function type() {
  const typing = document.getElementById("typing");

  if (i < sentences.length) {
    if (!isDeleting) {
      current = sentences[i].substring(0, j++);
    } else {
      current = sentences[i].substring(0, j--);
    }

    typing.innerHTML = current;

    if (!isDeleting && j === sentences[i].length) {
      isDeleting = true;
      setTimeout(type, 1500);
    } else if (isDeleting && j === 0) {
      isDeleting = false;
      i = (i + 1) % sentences.length;
      setTimeout(type, 500);
    } else {
      setTimeout(type, isDeleting ? 40 : 80);
    }
  }
}

type();
